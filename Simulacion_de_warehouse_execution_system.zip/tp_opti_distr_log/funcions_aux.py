import json
from datetime import datetime
import copy

 #Leemos el backlog de ordenes
with open('backlog.json', 'r') as f:
    backlog_data = json.load(f)

metadata = backlog_data['metadata']
 #ordeno las ordenes por fecha de vencimient0
ordenes = sorted(backlog_data['orders'], key=lambda x: x['due_date'], reverse=True)

def buscar_caras_que_cubren_ordenes(stock, lista_ordenes):
    """
    Dada una lista de órdenes, busca en el stock las caras de racks que pueden cumplir cada orden 
    y se fija que órdenes solo pueden ser cubiertas por un rack específico, llamemosla órdenes 
    exclusivas.

    Parámetros:
    - stock: Estructura de stock actual 
    - lista_ordenes: [{order_id, item_id, quantity, due_date}, ...] (subconjunto de órdenes manteniendo el mismo formato)

    Retorna: 
    - caras_por_orden: {order_id: [(rack, cara), ...], order_id: [(rack, cara), ...], ...}
      Diccionario donde la clave es el order_id y el valor son las caras que pueden cumplir esa orden
    - exclusivas: ['order_id', ...]  
      lista de order_id de órdenes exclusivas
    """
    caras_por_orden = {}
    exclusivas = []
    
    for orden in lista_ordenes:
        order_id = orden["order_id"]
        item_id = orden["item_id"]
        qty_requerida = orden["quantity"]
        
        caras_validas = []
        racks_encontrados = set()  # Para contar cuántos racks distintos
        
        # Buscar en cada rack y cara
        for rack_id, caras in stock.items():
            for cara_id, items in caras.items():
                # Revisar si esta cara tiene el item con suficiente cantidad
                for item in items:
                    if item["Inventory ID"] == item_id and item["Cantidad"] >= qty_requerida:
                        caras_validas.append((rack_id, cara_id))
                        racks_encontrados.add(rack_id)
                        break
        
        caras_por_orden[order_id] = caras_validas
        
        # Es exclusiva si solo hay 1 rack que la cubre
        if len(racks_encontrados) == 1:
            exclusivas.append(orden)
    
    return caras_por_orden, exclusivas


def actualizar_stock(item_id, cant, rack, cara,stock):
    """
    Actualiza (reduce) el stock global de un item en una cara de un rack
    
    Parámetros:
    - item_id: ID del producto a actualizar
    - cant: cantidad a reducir
    - rack: ID del rack
    - cara: ID de la cara
    
    Retorna:
    - res si redujo, especificando nivel y pos donde se redujo
    - {} si no pudo reducir (no hay suficiente stock)
    
    Nota: Modifica por referencia la variable 'stock'
    """
    # Inicializamos res como dicc para guardar la info de la ubicacion del item que buscamos
    res={"rack":"","cara":"","nivel":"","pos":""}

    # Verificar que el rack y cara existen
    if rack not in stock or cara not in stock[rack]:
        return {}
    
    items = stock[rack][cara]
    cantidad_a_reducir = cant
    
    # Buscamos en ese rack cara al item, una vez que lo encontramos 
    # nos quedamos con esa ubi y guardamos tambien su nivel y posicion
    for item in items[:]:
        if item["Inventory ID"] == item_id:
            if item["Cantidad"] >= cantidad_a_reducir:
                item["Cantidad"] -= cantidad_a_reducir
                nivel=item["Nivel"]
                pos=item["Posicion"]
                res['rack']=rack
                res['cara']=cara    
                res['nivel']=nivel  
                res['pos']=pos

                if item["Cantidad"] == 0:
                    items.remove(item)
                
                return res
    # Si no encontramos al item, retornamos {}
    return {}
        
def restock(pendientes,ubicaciones,stock):
    '''
    Restockea. Dado un conjunto de ordenes pendientes y las ubicaciones de 
    rack,cara,nivel,posicion de donde se extrajo el item que la cubre, se devuelve
    la cantidad correspondiente a esa ubicacion.


    Parámetros: 
    - pendientes : lista de diccionarios de ordenes pendients que queremos restockear
    - ubicaciones : diccionario con clave order_id y valor el rack,cara,nivel,pos
    - stock : el stock del momento. Loo actualizamos por referencia

    Retorna:
    True, solo para que devuelva algo. No nos interesa devolver algo, sino que actualizar.
    '''

    # Buscamos la ubicacion correspondiente para cada orden
    for orden in pendientes:
        encontrado=False
        o_id=orden['order_id']
        item=orden['item_id']
        cant=orden['quantity']
        rack=ubicaciones[o_id]['rack']
        cara=ubicaciones[o_id]['cara']
        nivel=ubicaciones[o_id]['nivel']
        pos=ubicaciones[o_id]['pos']
        inventario=stock[rack][cara]
        for elem in inventario:
            # Chequeamos si la ubicacion existe, ya que en el momento que se
            # queda sin unidades, se borra el inventario de la misma.
            if elem['Inventory ID']==item and elem['Nivel']==nivel and elem['Posicion']==pos:
                elem['Cantidad']+=cant # Si existe, devuelvo la cantidad
                encontrado=True
                break
        if not encontrado: #no lo encontro, asique hay q agregarlo porque se borro
            informacion={"Inventory ID": item,
                        "Cantidad": cant,
                        "Nivel": nivel,
                        "Posicion": pos}
            inventario.append(informacion)
    return True
            

    

def hay_stock(item_id, cant, rack, cara, stock, nivel=None, pos=None):
    """
    Verifica si hay suficiente stock en la variable global 'stock'.

    Parámetros : 
    - item_id : id del item que queremos saber si hay stock
    - cant: cantidad buscada
    - rack: rack en el que buscamos
    - cara: cara en la que buscamos
    -stock: stock del momento sobre el que buscamos.
    Opcionales: nivel y posicion buscadas.

    Retorna:
    - True si hay stock suficiente para cubrir el item y su cantidad en la ubicacion deseada
    - False en caso contrario.
    """
    #Si no existe la ubicacion, devolvemos false.
    if rack not in stock or cara not in stock[rack]:
        return False
    
    items = stock[rack][cara]
    cantidad_disponible = 0
    
    # Dentro de una cara, buscamos el item
    for item in items:
        if item["Inventory ID"] != item_id:
            continue
        # Si nos dan ubi especificaa, busco ahí.
        if nivel is not None and pos is not None:
            if item["Nivel"] == nivel and item["Posicion"] == pos:
                cantidad_disponible += item["Cantidad"]
        # Si solo tengo el nivel, busco en las posiciones de ese nivel.
        elif nivel is not None:
            if item["Nivel"] == nivel:
                cantidad_disponible += item["Cantidad"]
        # Si no me piden nivel y pos especifica, cuento stock del item en la cara total.
        else:
            cantidad_disponible += item["Cantidad"]
    
    return cantidad_disponible >= cant


def calcular_variedad_rack(rack_data):
    """
    Calcula cuántos Inventory IDs únicos hay en un rack (sumando todas sus caras).  

    Parámetros: 
    rack_data: informacion de un rack 
    {"Rack_id": "Cara_1": [{"Inventory ID": id,
                            Cantidad": c,
                            "Nivel": n,
                            "Posicion": p}...],
                "Cara_2":...}
    Retorna la cantidad de items distintos en un rack.
    """
    inventory_ids_unicos = set()
    
    for cara_nombre, items in rack_data.items():
        # Cada cara contiene una lista de items
        for item in items:
            inventory_ids_unicos.add(item['Inventory ID'])
    
    return len(inventory_ids_unicos)

def que_orden_cubre_rack(rack_id, ya_cubiertas,ordenes,stock):
    """
    Dado un rack, devuelve los IDs de las órdenes NO listas que puede cubrir.
    Como cada orden tiene un solo producto, solo verificamos ese item.

    Parámetros:
    - rack_id: id del rack cuyo cubrimiento nos interesa
    - ya_cubiertas: diccionario que nos dice para cada orden si ya fue cubierta o no.
    -ordenes: backlog de ordenes
    -stock: stock del momento

    Retorna:
    - ordenes_cubiertas: lista de ordenes que el rack cuyo id es rack_id cubre.
    """
    ordenes_cubiertas = []
    
    # Recorro todas las órdenes que NO están listas
    for orden in ordenes:
        if ya_cubiertas[orden['order_id']]:
            continue  # Salto las que ya están listas
        
        # Como cada orden tiene UN solo producto
        item = orden['item_id']
        cantidad_necesaria = orden['quantity']
        
        # Cuento cuánto stock de este item_id hay en el rack
        cantidad_en_rack = 0
        rack_data = stock[rack_id]
        
        for cara_nombre, items_cara in rack_data.items():
            for item_stock in items_cara:
                if item_stock['Inventory ID'] == item:
                    cantidad_en_rack += item_stock['Cantidad']
        
        # Si hay suficiente cantidad, esta orden se puede cubrir
        if cantidad_en_rack >= cantidad_necesaria:
            ordenes_cubiertas.append(orden)
    
    return ordenes_cubiertas

def seleccion_tibios(racks_ordenados,tibios):
    """
    Selecciona el subconjunto de tibios que se encuentra entre el 25% de los racks más variados.

    Parámetros: 
    - racks_ordenados: lista de racks ordenados por variedad de forma decreciente
    - tibios: lista de racks tibios.

    Retorna:
    - selectos: lista de ids de los racks tibios que tambien son variados.
    """
    miro_hasta=len(racks_ordenados)//4#nos interesa el 25% más variado
    selectos=[]
    for t_id in tibios:
        for r in racks_ordenados[:miro_hasta]:
            if r['rack_id']==t_id:
                selectos.append(t_id)
                break
    return selectos
            

