import json
from datetime import datetime, timedelta

def clasificar_racks_ciclo(resultado_ciclo, tibios_ciclo):
    # Leemos la entrada del ciclo
    resultado = resultado_ciclo['res']

    res = {}
    for key, ordenes in resultado.items():
        rack, cara = key.split('|')
        res[(rack, cara)] = ordenes
    
    # Inicializamos contadores
    racks_vistos = set()
    calientes = 0
    tibios = 0
    frios = 0

    # Clasificamos cada rack
    for clave, valor in res.items():
        rack, cara = clave

        # Si lo vimos, el rack es caliente
        if rack in racks_vistos:
            calientes += 1
        # Si está entre los tibios del ciclo, es tibio
        elif rack in tibios_ciclo:
            tibios += 1
        # Si no, es frío
        else:
            frios += 1

        racks_vistos.add(rack)

    return {
        'calientes': calientes,
        'tibios': tibios,
        'frios': frios, 
        'total_racks': len(racks_vistos)
    }

def calcular_metricas(archivo_resultados='resultados_stock1_24h.json'):
    """
    Calcula métricas de rendimiento a partir de los resultados de la simulación.
    """
    
    # Cargar resultados
    with open(archivo_resultados, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Extraer la lista de resultados
    if 'resultados' in data:
        resultados = data['resultados']
    else:
        resultados = data
    
    # Leer stock y backlog
    with open('stock.json', 'r', encoding='utf-8') as f:
        stock_data = json.load(f)

    with open('backlog.json', 'r', encoding='utf-8') as f:
        backlog_data = json.load(f)

    ordenes_dict = {orden['order_id']: orden for orden in backlog_data['orders']}

    # Para métricas 5.1
    total_ordenes_cubiertas = 0
    total_caras_utilizadas = 0
    total_tiempo_ejecucion = 0
    
    total_racks_calientes = 0
    total_racks_tibios = 0
    total_racks_frios = 0

    # Para métricas 5.2
    ordenes_por_hora = {}  
    pendientes_por_ciclo = []  

    # Para métricas 5.3
    ordenes_procesadas = {}
    ordenes_vencidas = set()

    # Para métricas 5.4
    tiempo_ciclos = []

    primera_orden = min(backlog_data['orders'], key=lambda x: x['due_date'])
    fecha_inicio = datetime.fromisoformat(primera_orden['due_date']).replace(hour=0, minute=0, second=0, microsecond=0)

    # Procesamos cada ciclo
    for ciclo_data in resultados:
        ciclo = ciclo_data['ciclo']
        
        # Calculamos la hora (ciclo 1 = minuto 0, ciclo 2 = minuto 5, etc.)
        minuto = (ciclo - 1) * 5
        hora = minuto // 60
        hora_actual = fecha_inicio + timedelta(minutes=minuto)
                
        # Contamos caras usadas en el ciclo
        caras_ciclo = len(ciclo_data['res'])
        total_caras_utilizadas += caras_ciclo

        # Contamos órdenes procesadas en este ciclo y en total
        total_pendientes = len(ciclo_data['pendientes'])
        ordenes_procesadas_ciclo = sum(len(ordenes) for ordenes in ciclo_data['res'].values())
        total_ordenes_cubiertas += ordenes_procesadas_ciclo - total_pendientes

        # Clasificamos racks
        tibios_ciclo = set(ciclo_data.get('tibios', []))
        clasificacion = clasificar_racks_ciclo(ciclo_data, tibios_ciclo)

        total_racks_calientes += clasificacion['calientes']
        total_racks_tibios += clasificacion['tibios']
        total_racks_frios += clasificacion['frios']

        # Calculamos el tiempo de ejecución
        total_tiempo_ejecucion += ciclo_data.get('tiempo_ejecucion', 0)    
        tiempo_ciclos.append(ciclo_data.get('tiempo_ejecucion', 0)) 

        # Acumulamos órdenes por hora
        if hora not in ordenes_por_hora:
            ordenes_por_hora[hora] = 0
        ordenes_por_hora[hora] += ordenes_procesadas_ciclo

        for ordenes_lista in ciclo_data['res'].values(): 
            for order_id in ordenes_lista:
                if order_id not in ordenes_procesadas:
                    ordenes_procesadas[order_id] = {
                        'ciclo': ciclo,
                        'hora': hora_actual
                    }


        # Identificar órdenes vencidas (que no se procesaron a tiempo)
        for order_id, orden_data in ordenes_dict.items():
            due_date = datetime.fromisoformat(orden_data['due_date'])
            
            # Si ya venció y no se procesó (o se procesó tarde)
            if hora_actual > due_date:
                if order_id not in ordenes_procesadas:
                    ordenes_vencidas.add(order_id)
                elif ordenes_procesadas[order_id]['hora'] > due_date:
                    ordenes_vencidas.add(order_id)

    # === MÉTRICA 5.1.1: PPF ===
    total_ordenes_cubiertas -= 1
    ppf_promedio = total_ordenes_cubiertas / total_caras_utilizadas if total_caras_utilizadas > 0 else 0

    # === MÉTRICA 5.1.2: Costo total de movimentación ===
    costo_total = (total_racks_calientes * 1 + 
                   total_racks_tibios * 3 +
                   total_racks_frios * 5)
    
    # === MÉTRICA 5.1.3: Costo medio por orden ===    
    costo_medio = costo_total / total_ordenes_cubiertas if total_ordenes_cubiertas > 0 else 0

    # === MÉTRICA 5.1.4: Distribución de racks por tipo ===
    total_racks_usados = total_racks_calientes + total_racks_tibios + total_racks_frios
    if total_racks_usados > 0:
        pct_calientes = (total_racks_calientes / total_racks_usados) * 100
        pct_tibios = (total_racks_tibios / total_racks_usados) * 100
        pct_frios = (total_racks_frios / total_racks_usados) * 100
    else:
        pct_calientes = pct_tibios = pct_frios = 0    

    # === MÉTRICA 5.2.1: Promedio de órdenes procesadas por hora ===
    total_ordenes = sum(ordenes_por_hora.values())
    horas_con_ordenes = len(ordenes_por_hora)
    promedio_por_hora = total_ordenes / horas_con_ordenes if horas_con_ordenes > 0 else 0
    
    # === MÉTRICA 5.2.2: Hora pico (máximo de órdenes procesadas) ===
    if ordenes_por_hora:
        hora_pico = max(ordenes_por_hora.items(), key=lambda x: x[1])
        max_ordenes = hora_pico[1]
        hora_max = hora_pico[0]
    else:
        hora_max = None
        max_ordenes = 0
    
    # === MÉTRICA 5.2.3: Valle (mínimo de órdenes procesadas) ===
    if ordenes_por_hora:
        valle = min(ordenes_por_hora.items(), key=lambda x: x[1])
        min_ordenes = valle[1]
        hora_min = valle[0]
    else:
        hora_min = None
        min_ordenes = 0
    
    # === MÉTRICA 5.3.1: SLA Compliance Rate ===
    total_ordenes_backlog = len(ordenes_dict)
    total_procesadas = len(ordenes_procesadas)
    total_vencidas = len(ordenes_vencidas)
    ordenes_a_tiempo = total_procesadas - total_vencidas
    sla_compliance = (ordenes_a_tiempo / total_procesadas * 100) if total_procesadas > 0 else 0

    # === MÉTRICA 5.3.2: Ordenes vencidas no proc ===
    ordenes_vencidas_no_procesadas = ordenes_vencidas - set(ordenes_procesadas.keys())
    pct_vencidas_no_procesadas = (len(ordenes_vencidas_no_procesadas) / total_ordenes_backlog * 100) if total_ordenes_backlog > 0 else 0

    # === MÉTRICA 5.3.3: Penalizaciones por vencimiento ===
    penalizacion_total = total_vencidas

    # === MÉTRICA 5.4.1: Varianza ===
    # En el archivo de varianza
    # === MÉTRICA 5.4.2: Estabilidad ===
    #Testeado aparte
    # === MÉTRICA 5.4.3: Tiempo de ejecución máximo ===
    tiempo_maximo_ciclo = max(tiempo_ciclos) if tiempo_ciclos else 0
    ciclo_mas_largo = tiempo_ciclos.index(tiempo_maximo_ciclo) + 1 if tiempo_ciclos else 0
    ventana_5_min = 300  # segundos
    cumple_ventana = tiempo_maximo_ciclo <= ventana_5_min

    # === MÉTRICA 5.4.4: Tiempo promedio por ciclo ===
    num_ciclos = len(resultados)
    tiempo_promedio_ciclo = total_tiempo_ejecucion / num_ciclos if num_ciclos > 0 else 0

    # Guardar métricas en TXT
    with open('metricas_con_stock1.txt', 'w', encoding='utf-8') as f:
        f.write("=" * 70 + "\n")
        f.write("MÉTRICAS DE EFICIENCIA Y RENDIMIENTO - SIMULACIÓN 24 HORAS\n")
        f.write("=" * 70 + "\n\n")
        
        f.write("╔═══════════════════════════════════════════════════════════════════╗\n")
        f.write("║  5.1 MÉTRICAS DE EFICIENCIA DEL SHELF SELECTOR                    ║\n")
        f.write("╚═══════════════════════════════════════════════════════════════════╝\n\n")
        
        f.write("1. PPF PROMEDIO (Picks Per Face)\n")
        f.write(f"   Total de órdenes cubiertas: {total_ordenes_cubiertas}\n")
        f.write(f"   Total de caras utilizadas: {total_caras_utilizadas}\n")
        f.write(f"   PPF promedio: {ppf_promedio:.2f} órdenes/cara\n\n")
        
        f.write("2. COSTO TOTAL DE MOVIMENTACIÓN\n")
        f.write(f"   Racks calientes (costo=1): {total_racks_calientes} × 1 = {total_racks_calientes}\n")
        f.write(f"   Racks tibios (costo=3): {total_racks_tibios} × 3 = {total_racks_tibios * 3}\n")
        f.write(f"   Racks fríos (costo=5): {total_racks_frios} × 5 = {total_racks_frios * 5}\n")
        f.write(f"   Costo total: {costo_total}\n\n")
        
        f.write("3. COSTO MEDIO POR ORDEN\n")
        f.write(f"   Costo total / Órdenes cubiertas: {costo_medio:.2f}\n\n")
        
        f.write("4. DISTRIBUCIÓN DE RACKS POR TIPO\n")
        f.write(f"   Racks calientes: {total_racks_calientes} ({pct_calientes:.1f}%)\n")
        f.write(f"   Racks tibios: {total_racks_tibios} ({pct_tibios:.1f}%)\n")
        f.write(f"   Racks fríos: {total_racks_frios} ({pct_frios:.1f}%)\n")
        f.write(f"   Total racks usados: {total_racks_usados}\n\n")
        

        f.write("\n")
        f.write("╔═══════════════════════════════════════════════════════════════════╗\n")
        f.write("║  5.2 MÉTRICAS DE RENDIMIENTO                                      ║\n")
        f.write("╚═══════════════════════════════════════════════════════════════════╝\n\n")
        
        f.write("1. PROMEDIO DE ÓRDENES PROCESADAS POR HORA\n")
        f.write(f"   Total de órdenes procesadas: {total_ordenes}\n")
        f.write(f"   Promedio por hora: {promedio_por_hora:.2f} órdenes/hora\n\n")
        
        f.write("2. HORA PICO\n")
        if hora_max is not None:
            f.write(f"   Hora: {hora_max}:00 - {hora_max}:59\n")
            f.write(f"   Órdenes procesadas: {max_ordenes}\n\n")
        else:
            f.write("   No hay datos\n\n")
        
        f.write("3. VALLE\n")
        if hora_min is not None:
            f.write(f"   Hora: {hora_min}:00 - {hora_min}:59\n")
            f.write(f"   Órdenes procesadas: {min_ordenes}\n\n")
        else:
            f.write("   No hay datos\n\n")
        
        f.write("\n")
        f.write("╔═══════════════════════════════════════════════════════════════════╗\n")
        f.write("║  5.3 MÉTRICAS DE NIVEL DE SERVICIO Y CUMPLIMIENTO DE SLA          ║\n")
        f.write("╚═══════════════════════════════════════════════════════════════════╝\n\n")
        
        f.write("1. SLA COMPLIANCE RATE\n")
        f.write(f"   Total de órdenes en backlog: {total_ordenes_backlog}\n")
        f.write(f"   Órdenes procesadas: {total_procesadas}\n")
        f.write(f"   Órdenes procesadas a tiempo: {ordenes_a_tiempo}\n")
        f.write(f"   Órdenes procesadas tarde: {total_vencidas}\n")
        f.write(f"   SLA Compliance Rate: {sla_compliance:.2f}%\n\n")
        
        f.write("2. ÓRDENES VENCIDAS NO PROCESADAS\n")
        f.write(f"   Total de órdenes vencidas no procesadas: {len(ordenes_vencidas_no_procesadas)}\n")
        f.write(f"   Porcentaje sobre total backlog: {pct_vencidas_no_procesadas:.2f}%\n\n")

        f.write("3. PENALIZACIONES POR VENCIMIENTO\n")
        f.write(f"   Penalización total: {penalizacion_total:.2f}\n\n")

        f.write("\n")
        f.write("╔═══════════════════════════════════════════════════════════════════╗\n")
        f.write("║  5.4 MÉTRICAS DE CALIDAD TÉCNICA DEL DESARROLLO                   ║\n")
        f.write("╚═══════════════════════════════════════════════════════════════════╝\n\n")
        
        f.write("1. COMPORTAMIENTO FRENTE A CASOS BORDE\n")
        f.write(f"  Prueba con stock vacío: Correcto. Corta en el ciclo 1.\n")
        f.write(f"  Prueba con backlog vacío: Correcto. Corta en el cilo 1.\n")
        f.write(f"  Prueba con stock insuficiente: Correcto. Corta la simulación tras el no procesamiento de ordenes.\n")#corresponde a la sim con el stock 1
        f.write(f"  Prueba con stock suficiente: Correcto\n")#corresponde a la sim con el stock 2
        f.write(f"  Pendientes y tibio vacío: Correcto.\n\n")#Corresponde con el ciclo 1 de las simulaciones.

        f.write("2. ESTABILIDAD: VARIANZA DE LA SOLUCIÓN ANTE UN MISMO INPUT\n")        
        f.write(f"  Se realizaron 10 ejecuciones separadas con el mismo input.\n")
        f.write(f"  Se eligieron de forma aleatoria los parametros, N=1075, Cantidad de pendientes=49 ,Cantidad de tibios=15 y se utilizo la misma lista de pendientes y tibios de dichas longitudes sampleados de forma aleatoria.\n")
        f.write(f"  En 10 simulaciones se usaron 60 racks.\n")        
        f.write(f"  En las 10 ejecuciones se registraron 1075 ordenes comunes (de 1075 totales).\n")
        f.write(f"  En las 10 ejecuciones se registraron 48 racks comunes (de 48 totales).\n\n")


        f.write("3. TIEMPO DE EJECUCIÓN MÁXIMO\n")
        f.write(f"   Ciclo más largo: Ciclo {ciclo_mas_largo}\n")
        f.write(f"   Duración: {tiempo_maximo_ciclo:.4f} segundos\n")
        f.write(f"   Ventana objetivo: {ventana_5_min} segundos (5 minutos)\n")
        if cumple_ventana:
            f.write(f"   Estado: ✓ CUMPLE con la ventana de 5 minutos\n")
            margen = ventana_5_min - tiempo_maximo_ciclo
            f.write(f"   Margen de seguridad: {margen:.2f} segundos ({(margen/ventana_5_min*100):.1f}%)\n\n")
        else:
            f.write(f"   Estado: ✗ NO CUMPLE con la ventana de 5 minutos\n")
            exceso = tiempo_maximo_ciclo - ventana_5_min
            f.write(f"   Exceso: {exceso:.2f} segundos\n\n")
                
        f.write("4. DURACIÓN PROMEDIO DE LAS ITERACIONES\n")
        f.write(f"   Tiempo total de ejecución: {total_tiempo_ejecucion:.2f} segundos\n")
        f.write(f"   Total de ciclos: {num_ciclos}\n")
        f.write(f"   Duración promedio: {tiempo_promedio_ciclo:.4f} segundos/ciclo\n")


    print("✓ Métricas completas guardadas")
    
    return 0


calcular_metricas()