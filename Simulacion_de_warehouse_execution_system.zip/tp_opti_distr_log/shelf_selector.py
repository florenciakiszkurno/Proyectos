from funcions_aux import restock,seleccion_tibios,buscar_caras_que_cubren_ordenes,hay_stock,actualizar_stock, calcular_variedad_rack, que_orden_cubre_rack
from datetime import datetime, timedelta
import json
import time
import copy
import random

#Leemos el backlog de ordenes
with open('backlog.json', 'r') as f:
    backlog = json.load(f)

metadata = backlog['metadata']

#ordeno las ordenes por fecha de vencimiento
ordenes = sorted(backlog['orders'], key=lambda x: x['due_date'])
#diccionario de ordenes cubiertas. Es True si la orden fue cubierta, False si no. Empiezan en False
cubiertas = {orden['order_id']: False for orden in ordenes} 

#Leemos el stock
with open('stock.json', 'r') as f:
    stock = json.load(f)

#Funcion para generar la simulacion
def generar_simulacion(ordenes, cubiertas, ordenes_ciclo_anterior=None, pendientes_ciclo_anterior=None, racks_ciclo_anterior=None):
    """
    Genera un diccionario de simulación para el shelf selector.

    Parámetros:
        ordenes: Órdenes ordenadas
        cubiertas: diccionario que indica si una orden fue cubierta
        ordenes_ciclo_anterior: Órdenes que se ejecutaron en el ciclo anterior, si las hay.
        pendientes_ciclo_anterior: Órdenes pendientes del ciclo anterior, si las hay.
        racks_ciclo_anterior: Lista de racks usados en el ciclo anterior, si los hay.

    Retorna:
        Estructura de simulación con claves 'N', 'pendientes' y 'tibios'.

    """
    # N aleatorio
    N = random.randint(1000, 2000)
    pendientes = [] 

    # Pendientes
    if ordenes_ciclo_anterior is not None: 
        # Ciclos posteriores a la primera iteración: simulamos que algunos no se pudieron ejecutar
        
        # Tomamos un subconjunto aleatorio de las órdenes del ciclo anterior que no hayan sido pendientes
        posibles_ordenes = [o for o in ordenes_ciclo_anterior if o['order_id'] not in {p['order_id'] for p in pendientes_ciclo_anterior}]        
        #Me aseguro que no tengo más pendientes que órdenes:
        num_pendientes = min(random.randint(1, 100), len(posibles_ordenes))        
        pendientes_ids = random.sample([o['order_id'] for o in posibles_ordenes], num_pendientes)
        pendientes = [o for o in ordenes if cubiertas[o["order_id"]] and o['order_id'] in pendientes_ids]

    # Definimos los racks tibios
    if racks_ciclo_anterior is None:
        # Primera iteración: No hay tibios
        tibios = []
    else:
        # Marcamos como tibios a un 20% aleatorio de los racks que se usaron en el ciclo anterior
        num_tibios = round(0.2 * len(racks_ciclo_anterior))
        tibios = random.sample(racks_ciclo_anterior, num_tibios)

    simulacion = {
        "N": N,
        "pendientes": pendientes,
        "tibios": tibios
    }

    return simulacion


def shelf_selector(n, pendientes, stock, tibios = []):
    """
    Algoritmo que simula una ejecución del shelf selector (SS). Proponemos una heurística que 
    prioriza racks con mayor variedad de productos, llenando las ordenes con vencimiento más 
    próximo, tratando de re utilizar los racks de las órdenes pendientes y los tibios con 
    mayor variedad. 

    Parámetros:
        n: Cantidad máxima de órdenes a cubrir en esta ejecución.
        pendientes: Órdenes pendientes del ciclo anterior, prioritarias para el ciclo actual.
        stock: Stock actual de todos los racks, que se actualiza por referencia.
        tibios: selección de racks tibios del ciclo anterior.

    Retorna:
        Un diccionario con claves (rack, cara) y como valor los ids de las órdenes cubiertas por ese par,
        una lista de órdenes imposibles de cubrir por falta de stock, 
        y un diccionario con información de dónde se obtuvo cada ítem, necesario para restockear en caso
        de que una orden sea devuelta como pendiente para ciclo posterior.

    """
    # Creamos una lista de racks con su variedad
    racks_con_variedad = [] #la idea es despues tener los racks ordenados por variedad
    for rack_id, rack_data in stock.items():
        variedad = calcular_variedad_rack(rack_data)
        racks_con_variedad.append({
            'rack_id': rack_id,
            'variedad': variedad,
            'data': rack_data
        })

    # Ordenamos los racks de MÁS variado a MENOS variado
    racks_ordenados = sorted(racks_con_variedad, key=lambda x: x['variedad'], reverse=True)

    # Inicializamos estructuras
    #diccionario de (rack,cara) : [order_id,...]
    res = {} 
    #diccionario que indica de que rack, cara, nivel y posición se saco el item para cada orden
    info_obt_ordenes={}
    # lista de order_id de ordenes pendientes imposibles de llenar con la cantidad de stock actual
    imposibles_por_stock = []
    #lista de order_id de ordenes cubiertas en la iteración actual
    ordenes_listas=[]

    #nos fijamos qué y cuántos racks cubririan las ordenes pendientes con una función auxiliar
    cubrimiento_ordenes, ordenes_exclusivas = buscar_caras_que_cubren_ordenes(stock,pendientes)
    #generamos un conjunto de racks que ya fueron usados, es decir, calientes, o son tibios
    tibios_o_usados=set(seleccion_tibios(racks_ordenados,tibios))
    #conjunto de pares (rack,cara) usados
    rc_usados=set()
    #conjunto de racks usados
    r_usados=set()

    #si un prod pendiente  es cubierto por un solo rack, debo incluirlo. llamemoslos racks obligatorios
    for orden in ordenes_exclusivas:
        exc=orden['order_id']
        #si no la cubri aun:
        if not cubiertas[exc]:
            #veo que racks y caras la cubren
            r_c=cubrimiento_ordenes[exc]
            for par in r_c:
                rack=par[0]
                cara=par[1]
                cant=orden['quantity']
                item_id=orden['item_id']
                #chequeo stock:
                if hay_stock(item_id,cant,rack,cara,stock):
                    #si hay stock, la cubro
                    rc_usados.add(par)
                    r_usados.add(par[0])
                    if par not in res:
                        res[par]=[exc]
                    else:
                        res[par].append(exc)
                    #actualizamos estructuras
                    ordenes_listas.append(exc)
                    cubiertas[exc]=True
                    #actualizo stock y me guardo info sobre de donde saque el item
                    info=actualizar_stock(item_id,cant,rack,cara,stock)
                    info_obt_ordenes[exc]=info
                    break
                else:
                    pass
                
    #tratamos de llenar ordenes pendientes con estos racks y las no pendientes permitidas (osea hasta n-longitud(pendientes)) con pronto venciemiento
    #relleno las pendientes no exclusivas
    for o_p in pendientes:
        cant = o_p['quantity']
        item_id = o_p['item_id']
        order_id = o_p['order_id']
        if not cubiertas[o_p['order_id']]: #si aun no la cubri
            #lista de pares r_c que calculamos antes que cubrian a la orden
            cub = cubrimiento_ordenes[o_p['order_id']]
            for par in cub:
                rack=par[0]
                cara=par[1]
                tibios_o_usados |= r_usados
                #Intentamos cubrirlo con un par usado y hay stock:
                if par in rc_usados and hay_stock(item_id,cant,rack,cara,stock):
                    #si hay stock, la cubro
                    #actualizo estructuras:
                    if par not in res:
                        res[par]=[o_p['order_id']]
                    else:
                        res[par].append(o_p['order_id'])
                    ordenes_listas.append(o_p['order_id'])
                    cubiertas[o_p['order_id']]=True
                    info=actualizar_stock(item_id,cant,rack,cara,stock)
                    info_obt_ordenes[o_p['order_id']]=info
                    break
                #si lo puedo cubrir con un rack usado o tibio pero no una cara usada
                elif rack in tibios_o_usados :
                    #recorremos todas las caras buscando stock
                    for c in ["Cara_1","Cara_2","Cara_3","Cara_4"]:
                        if c!= cara and hay_stock(item_id,cant,rack,c,stock):
                            new_par=(rack,c)
                            r_usados.add(rack)#porq si es tibio lo tengo que agregar
                            rc_usados.add(new_par)
                            if new_par not in res:
                                res[new_par]=[o_p['order_id']]
                            else:
                                res[new_par].append(o_p['order_id'])
                            ordenes_listas.append(o_p['order_id'])
                            cubiertas[o_p['order_id']]=True
                            info=actualizar_stock(item_id,cant,rack,c,stock)
                            info_obt_ordenes[o_p['order_id']]=info
                            break
                        else:
                            pass
                else:
                    pass
            #Para toda orden pendiente que no pude cubrir con racks usados o tibios, 
            # la trato de cubrir con un rack nuevo, priorizando los más variados:
            if not cubiertas[o_p['order_id']]:
                #creamos una variable stop para salir del doble for cuando la cubrimos
                stop=False
                for rack in racks_ordenados: 
                    if(stop):
                        break
                    rackid = rack['rack_id'] #me quedo con el rack mas variado que aun no vi  
                    if rackid not in r_usados:
                        for c in ["Cara_1","Cara_2","Cara_3","Cara_4"]:
                            # me fijo si hay stock para esa cara :
                            if hay_stock(item_id,cant,rackid,c,stock):
                                #si hay stock, la cubro
                                new_par=(rackid,c) 
                                #actualizo estructuras:
                                rc_usados.add(new_par)
                                r_usados.add(rackid)
                                if new_par not in res:
                                    res[new_par]=[o_p['order_id']]
                                else:
                                    res[new_par].append(o_p['order_id'])
                                ordenes_listas.append(o_p['order_id'])
                                cubiertas[o_p['order_id']]=True
                                info=actualizar_stock(item_id,cant,rackid,c,stock)
                                info_obt_ordenes[o_p['order_id']]=info
                                stop=True
                                break
                            else:
                                pass
                    else:
                        pass
        else:
            pass #las exclusivas las llenamos antes

    #cuando termino de recorrer las pendientes me fijo si alguna no se completo
    if(len(ordenes_listas)!=len(pendientes)):# si hay pendientes imposibles
        for o in pendientes:
            if(not cubiertas[o['order_id']]):
                imposibles_por_stock.append(o['order_id']) #me las guardo
            else:
                pass
    else: #no hay pendientes imposibles
        pass
    #LISTO LAS PENDIENTES -------------------------------------------

    #relleno las no pendientes
    #Primero voy a tratar de llenar las ordenes no pendientes con los racks y caras ya usados o tibios
    tibios_o_usados |= r_usados  
    for rack in tibios_o_usados:
        if len(ordenes_listas)==n: #chequeo si ya cumpli con las órdenes necesarias        
            break
        #Dado un rack, devuelve el conj de ordenes q cubre
        rack_cubrimiento = que_orden_cubre_rack(rack,cubiertas,ordenes,stock) 

        #Como las ordenes estaban ya ordenadas por fecha de vencimiento, sigo priorizando las q se vencen antes
        for orden_actual in rack_cubrimiento: 
            if len(ordenes_listas)==n: #chequeo si ya cumpli con las órdenes necesarias 
                break
            if cubiertas[orden_actual['order_id']]: #si la orden esta cubierta
                #ya cubri la orden CON OTRO RACK  asi que no tiene sentido buscar cubrirla otra vez
                continue 
            for cara in ["Cara_1","Cara_2","Cara_3","Cara_4"]:
                if hay_stock(orden_actual['item_id'],orden_actual['quantity'],rack,cara,stock):
                    #si hay stock, la cubro
                    new_par=(rack,cara)
                    #actualizo estructuras:
                    rc_usados.add(new_par)
                    r_usados.add(rack)
                    if new_par not in res:
                        res[new_par]=[orden_actual['order_id']]
                    else:
                        res[new_par].append(orden_actual['order_id'])
                    ordenes_listas.append(orden_actual['order_id']) 
                    cubiertas[orden_actual['order_id']]=True
                    info=actualizar_stock(orden_actual['item_id'],orden_actual['quantity'],rack,cara,stock)
                    info_obt_ordenes[orden_actual['order_id']]=info
                    break
                    #si no la pude cubrir, la dejo para después. priorizamos las que puedo cubrir con los racks calientes o tibios

    #LISTO LAS NO PENDIENTES QUE SE PODIAN CUBRIR CON racks calientes o tibios-----------------
    #para cada rack mas variado, lo lleno con la mayor cant de ordenes hasta completarlas.
    for racks in racks_ordenados: 
        rack=racks['rack_id']
        if len(ordenes_listas)==n: #chequeo si tiene sentido seguir recorriendo racks        
            break
        #calculo qué ordenes puedo cubrir con este rack
        rack_cubrimiento=que_orden_cubre_rack(rack,cubiertas,ordenes,stock) 
        #Como las ordenes estaban ya ordenadas por fecha de vencimiento, sigo priorizando las q se vencen antes
        for orden_actual in rack_cubrimiento: 
            if len(ordenes_listas)==n: #chequeo si ya cumpli con las órdenes necesarias
                break
            if cubiertas[orden_actual['order_id']]: #si la orden esta cubierta
                #ya cubri la orden CON OTRO RACK  asi que no tiene sentido buscar cubrirla otra vez
                continue 
            for cara in ["Cara_1","Cara_2","Cara_3","Cara_4"]:
                if hay_stock(orden_actual['item_id'],orden_actual['quantity'],rack,cara,stock):
                    #si hay stock, la cubro
                    new_par=(rack,cara)
                    #actualizo estructuras:
                    rc_usados.add(new_par)
                    r_usados.add(rack)
                    if new_par not in res:
                        res[new_par]=[orden_actual['order_id']]
                    else:
                        res[new_par].append(orden_actual['order_id'])
                    ordenes_listas.append(orden_actual['order_id']) 
                    cubiertas[orden_actual['order_id']]=True
                    info=actualizar_stock(orden_actual['item_id'],orden_actual['quantity'],rack,cara,stock)
                    info_obt_ordenes[orden_actual['order_id']]=info
                    break
    
    #YA TERMINE DE CUMPLIR LAS ORDENES NO PENDIENTES QUE PODIA (N-pendientes(sin contar imposibles))------------------------
        
    return res, imposibles_por_stock, info_obt_ordenes 

def main():
    # Inicialización
    stock_actual = copy.deepcopy(stock)  # Stock acumulativo
    racks_ciclo_anterior = None
    ordenes_cumplidas_ciclo_anterior = None
    pendientes_cilco_anterior = None
    info_ordenes={}
    resultados_totales = []

    # arrancamos el dia a las 00:00
    fecha_inicio = datetime.fromisoformat(backlog['orders'][0]['due_date']).replace(hour=0, minute=0, second=0, microsecond=0)
    
    #contador de iteraciones
    iteraciones=1

    # Ciclos de 5 minutos para 24 h
    for minuto in range(0, 24*60, 5):
        if minuto > 0 and cant_cubiertas < simulacion['N']:
            print("No se pueden cumplir más ordenes en el backlog")
            print(f"Se finalizó la simulación en el ciclo:{iteraciones-1}")
            break
        else: 
            hora_actual = fecha_inicio + timedelta(minutes=minuto)
            print(hora_actual)
            print(f"\n--- Ciclo {minuto//5 + 1} (Minuto {minuto}) ---")
            # Generar simulación para este ciclo
            simulacion = generar_simulacion(
                ordenes,
                cubiertas,
                ordenes_cumplidas_ciclo_anterior,
                pendientes_cilco_anterior,
                racks_ciclo_anterior
            )

            # "Reagregamos" las ordenes no cumplidas por el TM al backlog
            for ord in simulacion['pendientes']:
                cubiertas[ord["order_id"]] = False

            # Devolvemos el stock de las pendients
            restock(simulacion['pendientes'],info_ordenes,stock_actual)

            # Ejecutamos shelf_selector
            start = time.perf_counter()

            res, imposibles, info_ordenes = shelf_selector(
                simulacion['N'],
                simulacion['pendientes'],
                stock_actual,
                simulacion['tibios'],
            )
            end = time.perf_counter()

            # Después de ejecutar shelf_selector:
            ventana_ciclo = timedelta(minutes=5)

            # Marcamos las imposibles como cubiertas para que no las vuelva a mirar
            for o in imposibles:
                cubiertas[o] = True

            # Obtenemos las órdenes que el SS seleccionó
            ordenes_ss = [o for o in ordenes if o['order_id'] in {oid for lista in res.values() for oid in lista}]

            # Convertimos el due_date a datetime si aún no está
            for o in ordenes_ss:
                if isinstance(o.get('due_date'), str):
                    o['due_date_dt'] = datetime.fromisoformat(o['due_date'])

            # Determinamos el rango de vencimiento del ciclo actual
            inicio_del_dia = fecha_inicio
            fin_del_ciclo = hora_actual + ventana_ciclo

            # Buscamos órdenes que vencen en este rango (desde que arrancó el día hasta fin de este ciclo)
            vencidas = [
                o['order_id']
                for o in ordenes_ss
                if inicio_del_dia <= o['due_date_dt'] <= fin_del_ciclo
            ]

            cant_cubiertas = sum(len(ordenes) for ordenes in res.values())
            print(f"Órdenes vencidas hasta el minuto {minuto + 5}: {len(vencidas)}")
            print(f"Tiempo de ejecución: {end - start:.2f} s")
            print(f"Órdenes a cubrir (N): {simulacion['N']}")
            print(f"Órdenes cubiertas: {cant_cubiertas}")
            print(f"Cantidad de ordenes pendientes: {len(simulacion['pendientes'])}")
            print(f"Cantidad de racks tibios: {len(simulacion['tibios'])}")

            # Guardarmos resultados de este ciclo
            resultados_totales.append({
                "ciclo": minuto//5 + 1,
                "res": res,
                "pendientes": [o['order_id'] for o in simulacion['pendientes']],
                "tibios": simulacion['tibios'],
                "tiempo_ejecucion": end - start
            })

            # Preparamos racks tibios y órdenes cumplidas para el siguiente ciclo
            racks_ciclo_anterior = list(set(rack for (rack, _) in res.keys()))
            ordenes_cumplidas_ciclo_anterior = ordenes_ss # ordenes que devolvio el SS
            # actualizamos pendientes
            pendientes_cilco_anterior = simulacion['pendientes']
            iteraciones+=1

    # Convertimos las claves (rack, cara) a string antes de guardar
    for resultado in resultados_totales:
        resultado["res"] = {f"{rack}|{cara}": ordenes for (rack, cara), ordenes in resultado["res"].items()}
    
    # Agregamos al final el resumen global de imposibles
    resultado_final = {
        "resultados": resultados_totales,
        "ultimo_ciclo": iteraciones - 1
    }

    # Guardamos resultados finales
    with open('simulacion_24h.json', 'w', encoding='utf-8') as f:
        json.dump(resultado_final, f, indent=4, ensure_ascii=False)

    print("\n✓ Simulación 24 h completada. Resultados guardados en 'resultados_24h.json'")

# --- Ejecutar main ---
if __name__ == "__main__":
    main()